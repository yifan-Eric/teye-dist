
// const host = 'http://10.92.36.11:8012/bg-platform-gateway';
const host = 'https://s.tct-teye.com/bg-platform-gateway';
const defaultDuration = 1000*60*60*24*7;//默认一周


function auth_accessToken(success,failed){
    if(localStorage.getItem("isLogin") !== "true"){
        failed()
    }else{
        success();
    }
    // const url = host+"/isExpiration";
    // const token = getCookie('access_token');
    // axios({
    //     method: 'GET',
    //     url,
    //     headers: {
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json',
    //         'Authorization':token? 'Bearer '+token : null,
    //     }
    // }).then(response=>{
    //     if([200,301,302].indexOf(response.status)>-1)
    //         if(response.data&&response.data.code===0&&response.data.data===false)
    //             success();
    //         else
    //             exchange_accessToken(success,failed);
    //     else
    //         exchange_accessToken(success,failed);
    // }).catch(()=>{
    //     exchange_accessToken(success,failed);
    // })
}
function exchange_accessToken(success,failed){
    const token = getCookie('refresh_token');
    if(token==null)
        failed();
    else{
        axios({
            method:'GET',
            url:host+'/refreshToken',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization':token? 'Bearer '+token : null,
            }
        }).then(response=>{
            if([200,301,302].indexOf(response.status)>-1){
                if(response.data&&response.data.code==0){
                    //正常获取数据后记录cookie
                    setCookie('access_token',response.data.data);
                    success();
                }else{
                    failed();
                }
            }
            else
                failed()
        }).catch(error=>{
            console.log('error',error);
            failed();
        })
    }
}

function getCookie(name) {
    var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
    if(arr=document.cookie.match(reg))
        return (arr[2]);
    else
        return null;
}
function setCookie(name,value,expireTime=defaultDuration){
    var exp = new Date();
    exp.setTime(exp.getTime() + expireTime||defaultDuration);
    var hostname = location.hostname;
    document.cookie = name + "="+ escape (value) + ";expires=" + exp.toUTCString()+";domain="+hostname+";path=/";
}
